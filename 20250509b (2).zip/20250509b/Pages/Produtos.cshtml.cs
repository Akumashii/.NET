using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Cryptography.X509Certificates;

namespace _20250509b.Pages
{
    public class ProdutoModel : PageModel
    {
        public List<Produto> Produtos { get; set; }
        public void OnGet()
        {
            Produtos = new List<Produto> 
            {
            new Produto { Descricao = "Coca Cola", Preco = 8.99m },
            new Produto { Descricao = "Bolacha", Preco = 4.99m },
            new Produto { Descricao = "Bolo", Preco = 12.99m },
            new Produto { Descricao = "Caderno", Preco = 9.99m },
            new Produto { Descricao = "L�pis", Preco = 0.99m }
            };
        }
    }

    public class Produto 
    {
        public string Descricao { get; set; }
        public decimal Preco { get; set; }
    }
}
