using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace _20250509b.Pages.Usuarios
{
    public class DetalharModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
