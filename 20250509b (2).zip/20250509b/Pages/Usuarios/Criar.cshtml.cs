using _20250509b.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Xml.Serialization;



namespace _20250509b.Pages.Usuarios
{
    public class CriarModel : PageModel
    {
        [BindProperty] //vincula os dados do formulario HTML as propriedades do modelo da pagina 
        //quando eu eunvio um formulario pelo metodo POST, o ASP.NET verifica os valores e campos
        public Usuario usuario { get; set; } // um objeto pra ser instanciado e armazenado no arquivo
        public void OnGet() //metodo que executa quando � chamado o metodo Get, ou seja, quando acesso
        {
        }
        public IActionResult OnPost()//metodo que executa quando � feito o metodo Post
        {
            //verifica se os dados enviados no formulario sao validos conforme as regras do modelo
            if(!ModelState.IsValid)
            {
                return Page();
            }
            else
            {
                //vou fazer o armazenamento destes dados dentro do seu arquivo texto
                using (var writer = new StreamWriter("usuarios.txt", true))
                {
                    writer.WriteLine(usuario.Id + ";" + usuario.Nome + ";" + usuario.Senha + ";" + usuario.Email);
                    return RedirectToPage("/Usuarios/Index");
                }
            }
        }

    }
}
