using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace _20250509b.Pages.Usuarios
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
