using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace _20250509b.Pages.Usuarios
{
    public class EditarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
